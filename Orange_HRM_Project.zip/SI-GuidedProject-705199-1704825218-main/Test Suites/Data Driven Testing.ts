<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>data driven testing</description>
   <name>Data Driven Testing</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>1</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>5675326e-fc23-4028-9e9c-1f5ca3c0981e</testSuiteGuid>
   <testCaseLink>
      <guid>19919acc-c5c4-4ba6-ae90-de78bab863cf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>2cf7298e-084a-445b-bb3e-d2e65fc05ecb</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Login Data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>aa9fceba-b134-40ab-b2e5-c96d5fb7b7f2</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>2cf7298e-084a-445b-bb3e-d2e65fc05ecb</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>0bab89b0-95de-4b4c-842a-39e31c9ef905</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>2cf7298e-084a-445b-bb3e-d2e65fc05ecb</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>81e2935d-c8f8-4e2c-a916-5a58b33c5f79</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
